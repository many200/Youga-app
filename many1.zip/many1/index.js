const conterDisplay = document.querySelector('.compter')
const mousemouve = document.querySelector('.weap')
console.log(mousemouve);
let conter = 0
window.addEventListener('mousemove', (e) => {
    mousemouve.style.top = e.pageY + "px"
    mousemouve.style.left = e.pageX + "px"
})

const bubbleMacker = () => {


   const bubble = document.createElement('span')
   bubble.classList.add('bubble')
   document.body.appendChild(bubble)
   const size = Math.random() * 200 + 100 + "px";
    
   bubble.style.height = size
   bubble.style.width = size
   bubble.style.top = Math.random() * 100 + "%"
   bubble.style.left = Math.random() * 100 + "%"
   bubble.style.right = Math.random() * 100 + "%"
   const plusMinus = Math.random() > 0.5 ? 1 : -1
    bubble.addEventListener('click', (e) =>  {
        ring()
        conter++
        conterDisplay.textContent = conter++
        bubble.remove()
        console.log(conter);
    })
    const ring = () => {
        const audio = new Audio(); 
        audio.src = "./coup.mp3"
        audio.play()
      }

   setTimeout(() => {
    bubble.remove()
   }, 8000);
   
}
setInterval((bubbleMacker) , 1000);